﻿#include <iostream>
#include<string>
#include <algorithm>
using namespace std;

class StringTools {
public:
	static int countVowels(string text) {
		if (text.empty()) {
			return 0;
		}
		string vowels = "auioyeóąęAĄEĘIOUÓY";
		int count = 0;
		for (int i = 0; i < text.size();i++) {
			for (int j = 0; j < vowels.size(); j++) {
				if (text[i] == vowels[j]) {
					count++;
				}
			}
		}
		return count;
	}

	static string deleteRepetitions(string text) {
		if (text.empty()) {
			return "";
		}
		string newString = "";
		for (int i = 0; i < text.size();i++) {
			if ((i == 0) || (text[i] != text[i - 1])) { newString += text[i]; };
		}
		return newString;
	}
};

int main(void) {
	setlocale(LC_ALL, "pl_PL");
	string text = "";
	cout << "Wprowadź tekst, by obliczyć ilość spółgłosek zawartych w nim i usunąć powtarzające się po sobie znaki: " << endl << endl;
	getline(cin, text);
	cout << "Ilość samogłosek w podanym tekście: " << StringTools::countVowels(text) << endl;
	cout << "Tekst bez powtórzeń znaków pod rząd: " << StringTools::deleteRepetitions(text) << endl;
}